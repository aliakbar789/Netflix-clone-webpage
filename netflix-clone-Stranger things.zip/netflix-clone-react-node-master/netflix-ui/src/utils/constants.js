export const API_KEY = "3d39d6bfe362592e6aa293f01fbcf9b9";
export const TMDB_BASE_URL = "https://api.themoviedb.org/3";
